<template>
  <div class="newPage">
      <h4>我是下拉【{{pageData.index}}】下面的【菜单1】下面的数据:{{pageData.val}}</h4>
  </div>
</template>
<script>
  export default {
    data() {
        return {
            pageData:""
        }
    },
    mounted() { // 路由取值
        this.pageData = this.$route.query.data;
    }
  }
</script>
<style scoped>
    
</style>