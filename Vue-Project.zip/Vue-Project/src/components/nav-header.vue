<template>
  <div class="header-nav">
    <el-menu
      :default-active="activeIndex2"
      class="el-menu-demo"
      mode="horizontal"
      @select="handleSelect"
      background-color="#314458"
      text-color="#fff"
      active-text-color="#ffd04b">
      <el-menu-item index="1">下拉1</el-menu-item>
      <el-menu-item index="2">下拉2</el-menu-item>
      <el-menu-item index="3">下拉3</el-menu-item>
    </el-menu>
  </div>
</template>

<script>
export default {
    data() {
      return {
        activeIndex: '1',
        activeIndex2: '1',
        navSideName:[
          {id:'1',name:'下拉1'},
          {id:'2',name:'下拉1'},
          {id:'3',name:'下拉1'},
        ],
        navSideName2:[
          {id:'1',name:'下拉2'},
          {id:'2',name:'下拉2'},
          {id:'3',name:'下拉2'},
        ],
        navSideName3:[
          {id:'1',name:'下拉3'},
          {id:'2',name:'下拉3'},
          {id:'3',name:'下拉3'},
        ]
      };
    },
    methods: {
      handleSelect(key, keyPath) { // 判断点击的是哪个
        console.log(key, keyPath);
        switch (key) {
          case '1':
            this.$emit('getNavData',this.navSideName)
            break;
          case '2':
            this.$emit('getNavData',this.navSideName2)
            break;
          case '3':
            this.$emit('getNavData',this.navSideName3)
            break;
        }
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.el-menu-item{
  padding: none;
  width: 33.3%;
  text-align: center;
  border-bottom: none!important;
  border-right: #d1dde8 2px solid;
  background-color: #5b7da0!important;
}
.el-menu--horizontal>.el-menu-item.is-active{
  background: #405d7b!important;
  border: none!important;
  color: #ffffff!important;
}
</style>
