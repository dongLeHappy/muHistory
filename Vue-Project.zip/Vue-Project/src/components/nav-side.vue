<template>
  <div class="aside" >
    <el-col :span="12">
        <el-menu
        default-active="1"
        class="el-menu-vertical-demo"
        background-color="#4a6b8e"
        text-color="#fff"
        active-text-color="#ffd04b">
        <el-submenu v-for="(item,i) in navData" :key="i" :index="item.id">
            <template slot="title">
            <i class="el-icon-notebook-2"></i>
            <span>{{item.name}}</span>
            </template>
            <el-menu-item-group>
            <el-menu-item @click="getIndex(item.name,item.id)" :index="item.id">菜单1</el-menu-item>
            </el-menu-item-group>
        </el-submenu>
        </el-menu>
    </el-col>
  </div>
</template>
<script>
  export default {
    props:['navData'], 
    data() {
      return {}
    },
    watch: {
        navData(newval,oldVal) { // 监听变化
            let val = {
                index:newval[0].name,
                val:111  
            };
            this.$emit('getName',val)
        }
    },
    methods: {
        getIndex(name,index) { // 点击菜单传值
            let val = {
                index:name,
                val:index == 1 ? '111' : index == 2 ? '222' : '333'  
            };
            this.$emit('getName',val)
        }
    }
  }
</script>
<style scoped>
    .aside{
        height: 100%;
        width: 20%;
        background: #4a6b8e;
    }
    .el-col-12{
        width: 100%!important;
    }
    .el-menu{
        border: none;
    }
    .el-submenu{
        border-bottom: 1px solid #9da4ab; 
    }
    .el-submenu.is-active{
        background: green;
    }
    .el-submenu__title i{
        color: #f0f9eb!important;
    }
    .el-submenu__icon-arrow.el-icon-arrow-down{
        color: #f0f9eb!important;
    }
</style>