<template>
  <div class="content-nav">
      <div class="dataContent">
        <h4>我是{{name.index}}下面的菜单1，我的数据是：{{name.val}}</h4>
        <el-input v-model="name.val" placeholder="请输入内容"></el-input>
        <el-button @click="newPage">新页面传值</el-button>
      </div>
  </div>
</template>
<script>
import NewPage from './newPage'
  export default {
    components:{
        NewPage
    },
    props:['name'], // 接收值
    data(){
        return {}
    },
    methods: {
        newPage() { // 路由跳转新页面。通过路由传参
            this.$router.push({path:'/newPage',query:{data:this.name}});
        }
    }
  }
</script>
<style scoped>
    .content-nav{
        width: 80%;
        height: 100%;
        background: #EBEEF5;
    }
    h4{
        text-align: center;
    }
    .el-input{
        width: 50%;
        margin-left: 20%; 
    }
    .dataContent{
        margin-top: 20%;
    }
    .el-button{
        margin: 10px 0 0 10px;
    }
</style>